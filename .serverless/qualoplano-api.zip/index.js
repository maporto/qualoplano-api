require('dotenv').config();

module.exports.handler = require('./src/app');